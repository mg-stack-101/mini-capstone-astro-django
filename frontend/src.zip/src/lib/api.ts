/** Same-origin /api requests work through the Astro development proxy. */
export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

async function readResponse<T>(response: Response): Promise<T> {
  const data = await response.json().catch(() => null);
  if (!response.ok)
    throw new ApiError(
      data?.message || `Request failed (${response.status}).`,
      response.status,
    );
  if (data === null)
    throw new Error(
      "The API returned an invalid response. Check that Django is running.",
    );
  return data as T;
}

/** Bound the complete request, including response-body parsing. */
async function requestJson<T>(
  endpoint: string,
  options: RequestInit,
  timeoutMs: number,
): Promise<T> {
  const controller = new AbortController();
  const external = options.signal;
  let timedOut = false;
  const cancel = () => controller.abort();
  if (external?.aborted) cancel();
  else external?.addEventListener("abort", cancel, { once: true });
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  try {
    return await readResponse<T>(
      await fetch(endpoint, { ...options, signal: controller.signal }),
    );
  } catch (err) {
    if (timedOut)
      throw new Error(
        `The server did not respond within ${timeoutMs / 1000} seconds. Please try again.`,
      );
    throw err;
  } finally {
    clearTimeout(timer);
    external?.removeEventListener("abort", cancel);
  }
}

export async function getJson<T>(
  endpoint: string,
  signal?: AbortSignal,
): Promise<T> {
  return requestJson<T>(
    endpoint,
    {
      credentials: "same-origin",
      headers: { Accept: "application/json" },
      cache: "no-store",
      signal,
    },
    15_000,
  );
}

// Django rotates the CSRF token after login; avoid caching a stale value.
async function tokenFor(csrfToken?: string): Promise<string> {
  if (csrfToken) return csrfToken;
  return (await getJson<{ csrfToken: string }>("/api/csrf/")).csrfToken;
}

export async function postForm<T = { message: string }>(
  endpoint: string,
  form: FormData,
  csrfToken?: string,
): Promise<T> {
  const token = await tokenFor(csrfToken);
  form.set("csrfmiddlewaretoken", token);
  return requestJson<T>(
    endpoint,
    {
      method: "POST",
      credentials: "same-origin",
      body: form,
      headers: { Accept: "application/json", "X-CSRFToken": token },
    },
    30_000,
  );
}

export async function patchJson<T>(
  endpoint: string,
  data: unknown,
): Promise<T> {
  const token = await tokenFor();
  return requestJson<T>(
    endpoint,
    {
      method: "PATCH",
      credentials: "same-origin",
      body: JSON.stringify(data),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "X-CSRFToken": token,
      },
    },
    30_000,
  );
}
