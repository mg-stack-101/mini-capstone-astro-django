import { useEffect, useState } from "react";
import { getJson } from "./api";
import type { Complaint, ComplaintStatus, Paginated } from "./types";

export function useComplaints(enabled: boolean) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<ComplaintStatus | "">("");
  const [page, setPage] = useState(1);
  const [revision, setRevision] = useState(0);
  const [data, setData] = useState<Paginated<Complaint>>({
    count: 0,
    next: null,
    previous: null,
    results: [],
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!enabled) return;
    const abort = new AbortController();
    setLoading(true);
    setError("");
    const timer = window.setTimeout(() => {
      const params = new URLSearchParams({
        page: String(page),
        search,
        status,
      });
      getJson<Paginated<Complaint>>(`/api/complaints/?${params}`, abort.signal)
        .then(setData)
        .catch((err) => {
          if (!abort.signal.aborted)
            setError(
              err instanceof Error ? err.message : "Unable to load complaints.",
            );
        })
        .finally(() => {
          if (!abort.signal.aborted) setLoading(false);
        });
    }, search ? 250 : 0);
    return () => {
      window.clearTimeout(timer);
      abort.abort();
    };
  }, [enabled, page, search, status, revision]);
  return {
    data,
    error,
    loading,
    page,
    setPage,
    refresh: () => setRevision((value) => value + 1),
    filters: {
      search,
      status,
      onSearchChange: (value: string) => {
        setSearch(value);
        setPage(1);
      },
      onStatusChange: (value: ComplaintStatus | "") => {
        setStatus(value);
        setPage(1);
      },
    },
  };
}
