import { cardClass } from "./ui";
export default function StatCard({
  label,
  value,
  icon,
  tone = "blue",
}: {
  label: string;
  value?: number;
  icon: string;
  tone?: "blue" | "orange" | "green" | "red";
}) {
  const colors = {
    blue: "bg-blue-50",
    orange: "bg-amber-50",
    green: "bg-emerald-50",
    red: "bg-red-50",
  };
  return (
    <div className={`${cardClass} flex items-center justify-between gap-3`}>
      <div className="min-w-0">
        <p className="break-words text-3xl font-bold text-teal-900">
          {value === undefined ? "—" : value.toLocaleString("en-US")}
        </p>
        <p className="mt-1 text-sm text-slate-500">{label}</p>
      </div>
      <span
        aria-hidden="true"
        className={`flex size-12 shrink-0 items-center justify-center rounded-xl text-2xl ${colors[tone]}`}
      >
        {icon}
      </span>
    </div>
  );
}
