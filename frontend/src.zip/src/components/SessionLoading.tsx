import { Feedback } from "./ui";

export default function SessionLoading({ error }: { error: string }) {
  return (
    <main id="main" className="mx-auto max-w-xl p-6 sm:py-16">
      {error ? (
        <>
          <Feedback error>{error}</Feedback>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 min-h-11 rounded-lg border border-teal-300 px-4 font-semibold text-teal-800"
          >
            Retry
          </button>
        </>
      ) : (
        <p role="status">Loading your account…</p>
      )}
    </main>
  );
}
