import { useState, type ReactNode } from "react";
import type { NavigationItem } from "../lib/types";
import { Brand } from "./ui";
import { postForm } from "../lib/api";

const defaultItems: NavigationItem[] = [
  { label: "Dashboard", href: "/admin_dashboard/", icon: "📊" },
  { label: "Complaints", href: "/admin_dashboard/#complaints", icon: "📋" },
  { label: "Reports", href: "/dashboard/", icon: "📝" },
];
export interface DashboardShellProps {
  children: ReactNode;
  activeHref?: string;
  items?: NavigationItem[];
  panelLabel?: string;
  logoutEndpoint?: string;
  csrfToken?: string;
  demo?: boolean;
}
export default function DashboardShell({
  children,
  activeHref = "/admin_dashboard/",
  items = defaultItems,
  panelLabel = "Administrator Panel",
  logoutEndpoint = "/api/logout/",
  csrfToken,
  demo = false,
}: DashboardShellProps) {
  const [open, setOpen] = useState(false);
  const [logoutError, setLogoutError] = useState("");
  const [loggingOut, setLoggingOut] = useState(false);
  async function logOut() {
    setLoggingOut(true);
    setLogoutError("");
    try {
      await postForm(logoutEndpoint, new FormData(), csrfToken);
      window.location.assign("/login/");
    } catch (err) {
      setLogoutError(err instanceof Error ? err.message : "Unable to log out.");
      setLoggingOut(false);
    }
  }
  return (
    <div className="min-h-dvh bg-[#f0f4f8]">
      <header className="flex items-center justify-between gap-3 bg-white p-4 shadow-sm lg:hidden">
        <Brand />
        <button
          type="button"
          aria-expanded={open}
          aria-controls="dashboard-navigation"
          onClick={() => setOpen(!open)}
          className="min-h-11 shrink-0 rounded-lg border border-teal-200 px-3 text-sm font-semibold text-teal-900"
        >
          {open ? "Close" : "Menu"}
        </button>
      </header>
      <aside className="bg-gradient-to-b from-[#1e4e54] to-[#163c41] text-white lg:fixed lg:inset-y-0 lg:left-0 lg:flex lg:w-64 lg:flex-col lg:overflow-y-auto">
        <div className="hidden border-b border-white/10 px-5 py-7 lg:block">
          <Brand light />
          <p className="mt-4 text-xs text-teal-200">{panelLabel}</p>
        </div>
        <nav
          id="dashboard-navigation"
          aria-label="Dashboard navigation"
          className={`${open ? "block" : "hidden"} px-3 py-4 lg:block lg:flex-1`}
        >
          <p className="px-3 pb-3 text-xs text-teal-200 lg:hidden">
            {panelLabel}
          </p>
          <ul className="space-y-1">
            {items.map((item) => (
              <li key={item.href}>
                <a
                  onClick={() => setOpen(false)}
                  href={item.href}
                  aria-current={activeHref === item.href ? "page" : undefined}
                  className={`flex min-h-12 items-center gap-3 rounded-lg px-3 py-3 text-sm ${activeHref === item.href ? "bg-white/15 font-semibold text-white" : "text-teal-100 hover:bg-white/10"}`}
                >
                  <span aria-hidden="true">{item.icon}</span>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-6 border-t border-white/15 pt-4">
            {demo ? (
              <a
                href="/login/"
                className="block rounded-lg bg-red-700 px-4 py-3 text-center text-sm font-semibold hover:bg-red-800"
              >
                Exit preview
              </a>
            ) : (
              <button
                onClick={logOut}
                disabled={loggingOut}
                className="min-h-11 w-full rounded-lg bg-red-700 px-4 py-3 text-sm font-semibold hover:bg-red-800 disabled:opacity-60"
              >
                {loggingOut ? "Logging out…" : "Log out"}
              </button>
            )}
            {logoutError && (
              <p role="alert" className="mt-3 text-sm text-red-100">
                {logoutError}
              </p>
            )}
          </div>
        </nav>
      </aside>
      <main id="main" className="min-w-0 p-4 sm:p-6 lg:ml-64 lg:p-8">
        <div className="mx-auto max-w-7xl">{children}</div>
      </main>
    </div>
  );
}
