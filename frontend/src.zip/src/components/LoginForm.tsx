import { useEffect, useState, type SubmitEvent } from "react";
import { postForm } from "../lib/api";
import type { SessionUser } from "../lib/types";
import {
  Brand,
  buttonClass,
  cardClass,
  Feedback,
  Field,
  inputClass,
} from "./ui";

export interface LoginFormProps {
  endpoint?: string;
  csrfToken?: string;
  successHref?: string;
  demo?: boolean;
}
export default function LoginForm({
  endpoint = "/api/login/",
  csrfToken,
  successHref,
  demo = false,
}: LoginFormProps) {
  const [visible, setVisible] = useState(false);
  const [username, setUsername] = useState("");
  const [remember, setRemember] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [note, setNote] = useState("");
  useEffect(() => {
    try {
      const saved = localStorage.getItem("barangayUsername");
      if (saved) {
        setUsername(saved);
        setRemember(true);
      }
    } catch {
      /* Storage may be unavailable. */
    }
  }, []);
  async function submit(event: SubmitEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setNote("");
    if (demo) {
      setNote(
        "Preview only. Connect your login endpoint to authenticate users.",
      );
      return;
    }
    const data = new FormData(event.currentTarget);
    data.set("username", username.trim());
    setBusy(true);
    try {
      const result = await postForm<{ user: SessionUser }>(
        endpoint,
        data,
        csrfToken,
      );
      try {
        if (remember) localStorage.setItem("barangayUsername", username.trim());
        else localStorage.removeItem("barangayUsername");
      } catch {
        /* Login can proceed without storage. */
      }
      window.location.assign(
        successHref ||
          (result.user.role === "admin"
            ? "/admin_dashboard/"
            : "/resident_dashboard/"),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sign in.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <main
      id="main"
      className="flex min-h-dvh items-center justify-center bg-gradient-to-br from-[#e3f4f6] to-[#d4eff2] px-4 py-10 sm:px-6"
    >
      <section
        className={`${cardClass} w-full max-w-md sm:p-9`}
        aria-labelledby="login-title"
      >
        <Brand />
        <h1 id="login-title" className="mt-8 text-2xl font-bold text-teal-900">
          Welcome back
        </h1>
        <p className="mb-7 mt-2 text-sm text-slate-500">
          Please sign in to continue.
        </p>
        <form onSubmit={submit} className="space-y-5" aria-busy={busy}>
          {csrfToken && (
            <input type="hidden" name="csrfmiddlewaretoken" value={csrfToken} />
          )}
          {error && <Feedback error>{error}</Feedback>}
          {note && <Feedback>{note}</Feedback>}
          <Field id="username" label="Username">
            <input
              id="username"
              name="username"
              autoComplete="username"
              required
              maxLength={150}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className={inputClass}
            />
          </Field>
          <Field id="password" label="Password">
            <div className="relative">
              <input
                id="password"
                name="password"
                type={visible ? "text" : "password"}
                autoComplete="current-password"
                required
                className={`${inputClass} pr-20`}
              />
              <button
                type="button"
                aria-controls="password"
                aria-pressed={visible}
                aria-label={visible ? "Hide password" : "Show password"}
                onClick={() => setVisible(!visible)}
                className="absolute inset-y-0 right-0 min-w-16 px-3 text-sm font-semibold text-teal-700"
              >
                {visible ? "Hide" : "Show"}
              </button>
            </div>
          </Field>
          <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 text-sm">
            <label className="flex min-h-11 items-center gap-2">
              <input
                type="checkbox"
                name="remember_me"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="size-4 accent-teal-700"
              />
              Remember username
            </label>
            <button
              type="button"
              onClick={() =>
                setNote(
                  "Please contact your system administrator to reset your password.",
                )
              }
              className="min-h-11 text-teal-700 underline"
            >
              Forgot password?
            </button>
          </div>
          <button
            disabled={busy}
            className={`${buttonClass} w-full`}
            type="submit"
          >
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </form>
        {demo && (
          <aside className="mt-5 rounded-lg border border-dashed border-teal-300 p-3 text-sm">
            <p className="mb-3 text-slate-600">
              Template preview · no authentication connected
            </p>
            <div className="flex flex-wrap gap-4">
              <a className="text-teal-800 underline" href="/admin_dashboard/">
                Preview admin
              </a>
              <a
                className="text-teal-800 underline"
                href="/resident_dashboard/"
              >
                Preview resident
              </a>
            </div>
          </aside>
        )}
        <p className="mt-6 text-center text-sm leading-relaxed text-slate-500">
          “Together we can build a stronger and safer community.”
        </p>
        <a
          className="mt-4 block py-2 text-center text-sm text-teal-700 underline"
          href="/"
        >
          ← Back to home
        </a>
      </section>
    </main>
  );
}
