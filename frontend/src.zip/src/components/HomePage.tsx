import { Brand, buttonClass } from "./ui";

export default function HomePage() {
  return (
    <div className="flex min-h-dvh flex-col bg-gradient-to-br from-[#e3f4f6] to-[#d4eff2]">
      <header className="mx-auto w-full max-w-6xl p-5 sm:p-8">
        <Brand />
      </header>
      <main
        id="main"
        className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center px-5 py-16 text-center"
      >
        <span
          aria-hidden="true"
          className="mb-7 rounded-3xl bg-white/70 p-6 text-5xl shadow-sm"
        >
          🏛️
        </span>
        <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-teal-700">
          Your voice. Our community.
        </p>
        <h1 className="text-3xl font-bold leading-tight text-[#1a3b5d] sm:text-5xl">
          Barangay Complaint
          <br />
          <span className="text-teal-700">Monitoring System</span>
        </h1>
        <p className="mt-6 max-w-lg text-base leading-relaxed text-slate-600 sm:text-lg">
          Welcome — please sign in to report a concern and help build a
          stronger, safer community.
        </p>
        <a href="/login/" className={`${buttonClass} mt-9 w-full sm:w-auto`}>
          Sign in to continue <span aria-hidden="true">→</span>
        </a>
      </main>
      <footer className="px-5 py-6 text-center text-sm text-slate-600">
        Together for a better barangay.
      </footer>
    </div>
  );
}
