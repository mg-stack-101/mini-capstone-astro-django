export default function Pagination({
  page,
  count,
  hasPrevious,
  hasNext,
  disabled,
  onPage,
}: {
  page: number;
  count: number;
  hasPrevious: boolean;
  hasNext: boolean;
  disabled: boolean;
  onPage: (page: number) => void;
}) {
  return (
    <nav
      aria-label="Complaint pages"
      className="mt-5 flex flex-wrap items-center justify-between gap-3 text-sm"
    >
      <p>
        Page {page} · {count} total results
      </p>
      <div className="flex gap-3">
        <button
          disabled={disabled || !hasPrevious}
          onClick={() => onPage(page - 1)}
          className="min-h-11 rounded-lg border border-teal-300 px-3 font-semibold text-teal-800 disabled:opacity-40"
        >
          Previous
        </button>
        <button
          disabled={disabled || !hasNext}
          onClick={() => onPage(page + 1)}
          className="min-h-11 rounded-lg border border-teal-300 px-3 font-semibold text-teal-800 disabled:opacity-40"
        >
          Next
        </button>
      </div>
    </nav>
  );
}
