import { useEffect, useState } from "react";
import { getJson, patchJson } from "../lib/api";
import { useSession } from "../lib/useSession";
import { useComplaints } from "../lib/useComplaints";
import type { ComplaintStatus, DashboardStats } from "../lib/types";
import AdminDashboard from "./AdminDashboard";
import Pagination from "./Pagination";
import SessionLoading from "./SessionLoading";
import { Feedback } from "./ui";

export default function LiveAdminDashboard() {
  const { user, error } = useSession("admin");
  const list = useComplaints(!!user);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);
  const [statsError, setStatsError] = useState("");
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    const abort = new AbortController();
    setStatsLoading(true);
    setStatsError("");
    getJson<DashboardStats>("/api/dashboard/", abort.signal)
      .then(setStats)
      .catch((err) => {
        if (!abort.signal.aborted)
          setStatsError(
            err instanceof Error ? err.message : "Unable to load statistics.",
          );
      })
      .finally(() => {
        if (!abort.signal.aborted) setStatsLoading(false);
      });
    return () => abort.abort();
  }, [revision]);
  async function updateStatus(id: string, status: ComplaintStatus) {
    await patchJson(`/api/complaints/${id}/status/`, { status });
    list.refresh();
    setRevision((value) => value + 1);
  }
  if (!user) return <SessionLoading error={error} />;
  return (
    <>
      <AdminDashboard
        adminName={user.name}
        complaints={list.data.results}
        stats={stats}
        statsLoading={statsLoading}
        tableProps={{
          remoteFilters: list.filters,
          onUpdateStatus: updateStatus,
        }}
        pagination={
          <>
            {list.loading && (
              <p role="status" className="mt-3 text-sm text-slate-500">
                Loading complaints…
              </p>
            )}
            {(list.error || statsError) && (
              <div className="mt-3">
                <Feedback error>{list.error || statsError}</Feedback>
                <button
                  onClick={() => {
                    list.refresh();
                    setRevision((value) => value + 1);
                  }}
                  className="min-h-11 px-2 text-teal-800 underline"
                >
                  Retry
                </button>
              </div>
            )}
            <Pagination
              page={list.page}
              count={list.data.count}
              hasPrevious={!!list.data.previous}
              hasNext={!!list.data.next}
              disabled={list.loading}
              onPage={list.setPage}
            />
          </>
        }
      />
    </>
  );
}
