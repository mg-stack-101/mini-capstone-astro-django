import { useSession } from "../lib/useSession";
import { useComplaints } from "../lib/useComplaints";
import ComplaintForm from "./ComplaintForm";
import ComplaintsTable from "./ComplaintsTable";
import DashboardShell from "./DashboardShell";
import Pagination from "./Pagination";
import SessionLoading from "./SessionLoading";
import { cardClass, Feedback } from "./ui";

export default function LiveResidentDashboard() {
  const { user, error } = useSession();
  const list = useComplaints(!!user);
  if (!user) return <SessionLoading error={error} />;
  return (
    <DashboardShell
      panelLabel="Resident Panel"
      activeHref="/resident_dashboard/"
      items={[
        {
          label: "Submit a complaint",
          href: "/resident_dashboard/",
          icon: "📝",
        },
        { label: "My complaints", href: "#my-complaints", icon: "📋" },
        { label: "Home", href: "/", icon: "🏠" },
      ]}
    >
      <ComplaintForm initialName={user.name} onSubmitted={list.refresh} />
      <section
        id="my-complaints"
        className={`${cardClass} mt-7 scroll-mt-5`}
        aria-labelledby="my-complaints-title"
      >
        <h2
          id="my-complaints-title"
          className="mb-5 text-xl font-bold text-teal-900"
        >
          {user.role === "admin" ? "Complaints" : "My Complaints"}
        </h2>
        <ComplaintsTable
          complaints={list.data.results}
          remoteFilters={list.filters}
        />
        {list.loading && (
          <p role="status" className="mt-3 text-sm">
            Loading complaints…
          </p>
        )}
        {list.error && (
          <div className="mt-3">
            <Feedback error>{list.error}</Feedback>
            <button
              onClick={list.refresh}
              className="min-h-11 px-2 text-teal-800 underline"
            >
              Retry
            </button>
          </div>
        )}
        <Pagination
          page={list.page}
          count={list.data.count}
          hasPrevious={!!list.data.previous}
          hasNext={!!list.data.next}
          disabled={list.loading}
          onPage={list.setPage}
        />
      </section>
    </DashboardShell>
  );
}
