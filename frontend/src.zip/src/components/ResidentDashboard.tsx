import ComplaintForm, { type ComplaintFormProps } from "./ComplaintForm";
import DashboardShell from "./DashboardShell";

export default function ResidentDashboard(
  props: ComplaintFormProps & { logoutEndpoint?: string },
) {
  return (
    <DashboardShell
      demo={props.demo}
      csrfToken={props.csrfToken}
      logoutEndpoint={props.logoutEndpoint}
      panelLabel="Resident Panel"
      activeHref="/resident_dashboard/"
      items={[
        {
          label: "Submit a complaint",
          href: "/resident_dashboard/",
          icon: "📝",
        },
        { label: "Home", href: "/", icon: "🏠" },
      ]}
    >
      <ComplaintForm {...props} />
    </DashboardShell>
  );
}
