import { useEffect, useState, type ReactNode } from "react";
import type { Complaint, DashboardStats } from "../lib/types";
import DashboardShell from "./DashboardShell";
import StatCard from "./StatCard";
import ComplaintsTable, { type ComplaintsTableProps } from "./ComplaintsTable";
import { cardClass } from "./ui";

export interface AdminDashboardProps {
  stats?: DashboardStats | null;
  statsLoading?: boolean;
  tableProps?: Omit<ComplaintsTableProps, "complaints">;
  pagination?: ReactNode;
  adminName?: string;
  complaints?: Complaint[];
  registeredUsers?: number;
  demo?: boolean;
  csrfToken?: string;
  logoutEndpoint?: string;
}
export default function AdminDashboard({
  adminName = "Admin",
  complaints = [],
  registeredUsers = 0,
  demo = false,
  csrfToken,
  logoutEndpoint,
  stats,
  statsLoading = false,
  tableProps,
  pagination,
}: AdminDashboardProps) {
  const [date, setDate] = useState("");
  useEffect(() => {
    setDate(
      new Intl.DateTimeFormat("en-PH", {
        dateStyle: "full",
        timeZone: "Asia/Manila",
      }).format(new Date()),
    );
  }, []);
  return (
    <DashboardShell
      demo={demo}
      csrfToken={csrfToken}
      logoutEndpoint={logoutEndpoint}
    >
      <header className="mb-7 flex flex-col justify-between gap-4 xl:flex-row xl:items-center">
        <div>
          <h1 className="break-words text-2xl font-bold text-teal-900 sm:text-3xl">
            Welcome, {adminName}! <span aria-hidden="true">👋</span>
          </h1>
          <p className="mt-2 text-sm text-slate-500">
            Barangay Complaint Monitoring System Overview
          </p>
        </div>
        <p className="w-fit rounded-lg bg-white px-4 py-3 text-sm text-teal-800 shadow-sm">
          {date || "Barangay administrator"}
        </p>
      </header>
      {demo && (
        <p className="mb-5 rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-900">
          Template preview · records below are sample data.
        </p>
      )}
      <section
        aria-label="System statistics"
        aria-busy={statsLoading}
        className="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4"
      >
        <StatCard
          label="Total Complaints"
          value={
            stats === null ? undefined : (stats?.total ?? complaints.length)
          }
          icon="📋"
        />
        <StatCard
          label="Pending"
          value={
            stats === null
              ? undefined
              : (stats?.pending ??
                complaints.filter((c) => c.status === "Pending").length)
          }
          icon="⏳"
          tone="orange"
        />
        <StatCard
          label="Resolved"
          value={
            stats === null
              ? undefined
              : (stats?.resolved ??
                complaints.filter((c) => c.status === "Resolved").length)
          }
          icon="✅"
          tone="green"
        />
        <StatCard
          label="Registered Users"
          value={
            stats === null
              ? undefined
              : (stats?.registeredUsers ?? registeredUsers)
          }
          icon="👥"
          tone="red"
        />
      </section>
      {statsLoading && (
        <p role="status" className="mb-5 text-sm text-slate-500">
          Loading statistics…
        </p>
      )}
      <section
        id="complaints"
        aria-labelledby="complaints-title"
        className={`${cardClass} scroll-mt-5`}
      >
        <h2
          id="complaints-title"
          className="mb-5 text-lg font-bold text-teal-900"
        >
          Recent Complaints
        </h2>
        <ComplaintsTable complaints={complaints} {...tableProps} />
        {pagination}
      </section>
    </DashboardShell>
  );
}
