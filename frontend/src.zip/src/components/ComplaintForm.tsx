import {
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type SubmitEvent,
} from "react";
import { postForm } from "../lib/api";
import { buttonClass, cardClass, Feedback, Field, inputClass } from "./ui";

export interface ComplaintFormProps {
  endpoint?: string;
  csrfToken?: string;
  demo?: boolean;
  initialName?: string;
  onSubmitted?: () => void;
}
const complaintTypes = [
  "Noise Disturbance",
  "Garbage Disposal",
  "Pet Nuisance",
  "Property Dispute",
  "Verbal Altercation",
  "Other",
];
export default function ComplaintForm({
  endpoint = "/api/complaints/",
  csrfToken,
  demo = false,
  initialName = "",
  onSubmitted,
}: ComplaintFormProps) {
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const form = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (!photo) {
      setPreview("");
      return;
    }
    const url = URL.createObjectURL(photo);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);
  function changePhoto(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    setPhoto(null);
    setError("");
    if (!file) return;
    if (
      !["image/jpeg", "image/png"].includes(file.type) ||
      file.size > 5 * 1024 * 1024 ||
      file.size === 0
    ) {
      setError("Please select a JPG or PNG image up to 5 MB.");
      event.target.value = "";
      return;
    }
    setPhoto(file);
  }
  async function submit(event: SubmitEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (!photo) {
      setError("Please upload a photo before submitting.");
      return;
    }
    const data = new FormData(event.currentTarget);
    for (const name of [
      "full_name",
      "contact_number",
      "address",
      "description",
    ]) {
      const value = String(data.get(name) || "").trim();
      if (!value) {
        setError("Please complete all required fields.");
        return;
      }
      data.set(name, value);
    }
    if (demo) {
      dialog.current?.showModal();
      return;
    }
    setBusy(true);
    try {
      await postForm(endpoint, data, csrfToken);
      dialog.current?.showModal();
      form.current?.reset();
      setPhoto(null);
      onSubmitted?.();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to submit your complaint.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section
      className={`${cardClass} mx-auto w-full max-w-2xl`}
      aria-labelledby="complaint-title"
    >
      <h1
        id="complaint-title"
        className="text-2xl font-bold text-teal-900 sm:text-3xl"
      >
        Submit a Complaint
      </h1>
      <p className="mb-7 mt-3 text-sm leading-relaxed text-slate-500">
        Fill out the form below to report an issue in your barangay. All fields
        are required.
      </p>
      {demo && (
        <p className="mb-5 rounded-lg bg-amber-50 p-3 text-sm text-amber-900">
          Preview mode: information and photos are not uploaded or saved.
        </p>
      )}
      <form
        ref={form}
        onSubmit={submit}
        encType="multipart/form-data"
        aria-busy={busy}
      >
        {csrfToken && (
          <input type="hidden" name="csrfmiddlewaretoken" value={csrfToken} />
        )}
        <fieldset disabled={busy} className="space-y-5 disabled:opacity-70">
          <legend className="sr-only">Complaint details</legend>
          {error && <Feedback error>{error}</Feedback>}
          <div className="grid gap-5 sm:grid-cols-2">
            <Field id="full_name" label="Your Full Name *">
              <input
                id="full_name"
                name="full_name"
                required
                autoComplete="name"
                maxLength={150}
                defaultValue={initialName}
                placeholder="Enter your full name"
                className={inputClass}
              />
            </Field>
            <Field id="contact_number" label="Contact Number *">
              <input
                id="contact_number"
                name="contact_number"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                required
                maxLength={30}
                placeholder="09XX-XXX-XXXX"
                className={inputClass}
              />
            </Field>
          </div>
          <Field id="address" label="Address / Purok *">
            <input
              id="address"
              name="address"
              autoComplete="street-address"
              required
              maxLength={300}
              placeholder="Your complete address"
              className={inputClass}
            />
          </Field>
          <Field id="complaint_type" label="Type of Complaint *">
            <select
              id="complaint_type"
              name="complaint_type"
              required
              defaultValue=""
              className={inputClass}
            >
              <option value="" disabled>
                Select complaint type
              </option>
              {complaintTypes.map((type) => (
                <option key={type}>{type}</option>
              ))}
            </select>
          </Field>
          <Field id="description" label="Description of Complaint *">
            <textarea
              id="description"
              name="description"
              required
              rows={5}
              maxLength={5000}
              placeholder="Describe what happened, when, and where…"
              className={`${inputClass} resize-y`}
            />
          </Field>
          <Field id="photo" label="Upload Photo / Evidence *">
            <div className="rounded-xl border-2 border-dashed border-teal-200 bg-teal-50/40 p-4 sm:p-5">
              <input
                id="photo"
                name="photo"
                type="file"
                accept="image/jpeg,image/png"
                required
                onChange={changePhoto}
                aria-describedby="photo-note"
                className="block w-full min-w-0 rounded text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-teal-100 file:px-3 file:py-3 file:font-semibold file:text-teal-900"
              />
              <p id="photo-note" className="mt-3 text-xs text-slate-500">
                JPG or PNG only · Maximum 5 MB · Photo is required.
              </p>
            </div>
          </Field>
          {preview && (
            <figure className="min-w-0">
              <img
                src={preview}
                alt="Selected evidence preview"
                className="max-h-60 w-full rounded-xl object-contain"
              />
              <figcaption className="mt-2 break-all text-xs text-slate-500">
                {photo?.name}
              </figcaption>
            </figure>
          )}
          <button type="submit" className={`${buttonClass} w-full`}>
            {busy
              ? "Submitting…"
              : demo
                ? "Preview submission"
                : "Submit complaint"}
          </button>
        </fieldset>
      </form>
      <dialog
        ref={dialog}
        aria-labelledby="success-title"
        aria-describedby="success-description"
        className="fixed inset-0 m-auto w-[calc(100%_-_2rem)] max-w-md rounded-2xl border-0 bg-white p-6 text-center text-slate-700 shadow-xl backdrop:bg-slate-950/50 sm:p-9"
      >
        <span aria-hidden="true" className="text-4xl">
          {demo ? "📋" : "✅"}
        </span>
        <h2
          id="success-title"
          className="mt-4 text-2xl font-bold text-teal-900"
        >
          {demo ? "Preview complete" : "Thank you!"}
        </h2>
        <p id="success-description" className="mt-3 text-sm leading-relaxed">
          {demo
            ? "Your form passed the browser checks. Nothing was submitted. Connect your complaint endpoint to save reports."
            : "Your complaint has been submitted. We will review it shortly. God bless you."}
        </p>
        <button
          type="button"
          autoFocus
          onClick={() => dialog.current?.close()}
          className={`${buttonClass} mt-6 w-full`}
        >
          OK
        </button>
      </dialog>
    </section>
  );
}
