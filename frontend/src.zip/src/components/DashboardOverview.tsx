import { Brand, cardClass } from "./ui";
import type { NavigationItem } from "../lib/types";

export default function DashboardOverview({
  adminName = "Administrator",
  links = [
    { label: "Complaints", href: "/admin_dashboard/#complaints", icon: "📋" },
    { label: "Detailed dashboard", href: "/admin_dashboard/", icon: "📊" },
    { label: "Submit a complaint", href: "/resident_dashboard/", icon: "📝" },
  ],
  demo = false,
}: {
  adminName?: string;
  links?: NavigationItem[];
  demo?: boolean;
}) {
  return (
    <div className="min-h-dvh bg-gradient-to-br from-[#e3f4f6] to-[#d4eff2]">
      <header className="flex flex-wrap items-center justify-between gap-4 bg-white p-5 sm:px-8">
        <Brand />
        <a
          href="/"
          className="min-h-11 rounded-lg border border-teal-200 px-4 py-3 text-sm font-semibold text-teal-800"
        >
          Home
        </a>
      </header>
      <main id="main" className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
        <section className={`${cardClass} mb-7 py-10 text-center`}>
          <h1 className="break-words text-2xl font-bold text-teal-800 sm:text-4xl">
            Welcome, {adminName}!
          </h1>
          <p className="mt-4 text-slate-500">
            Barangay Complaint Monitoring System
          </p>
          <span className="mt-5 inline-block rounded-full bg-teal-700 px-5 py-2 text-sm font-semibold text-white">
            {demo ? "TEMPLATE PREVIEW" : "ADMINISTRATOR DASHBOARD"}
          </span>
        </section>
        <nav
          aria-label="Quick links"
          className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`${cardClass} group text-center transition-colors hover:border-teal-500`}
            >
              <span aria-hidden="true" className="text-3xl">
                {link.icon}
              </span>
              <h2 className="mt-4 font-semibold text-teal-900">{link.label}</h2>
              <p className="mt-2 text-sm text-slate-500">
                Open <span aria-hidden="true">→</span>
              </p>
            </a>
          ))}
        </nav>
      </main>
    </div>
  );
}
