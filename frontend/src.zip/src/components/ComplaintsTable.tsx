import { useState } from "react";
import type { Complaint, ComplaintStatus } from "../lib/types";
import { buttonClass, Feedback, inputClass, StatusBadge } from "./ui";

export interface RemoteFilters {
  search: string;
  status: ComplaintStatus | "";
  onSearchChange: (value: string) => void;
  onStatusChange: (value: ComplaintStatus | "") => void;
}
export interface ComplaintsTableProps {
  complaints?: Complaint[];
  remoteFilters?: RemoteFilters;
  onUpdateStatus?: (id: string, status: ComplaintStatus) => Promise<void>;
}
function StatusEditor({
  row,
  update,
}: {
  row: Complaint;
  update: NonNullable<ComplaintsTableProps["onUpdateStatus"]>;
}) {
  const [status, setStatus] = useState(row.status);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState(false);
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setMessage("");
        setError(false);
        try {
          await update(row.id, status);
          setMessage("Status updated.");
        } catch (err) {
          setError(true);
          setMessage(
            err instanceof Error ? err.message : "Unable to update status.",
          );
        } finally {
          setBusy(false);
        }
      }}
      className="mt-4 space-y-3"
    >
      <label htmlFor="update-status" className="block text-sm font-semibold">
        Update complaint status
      </label>
      <div className="flex flex-wrap gap-3">
        <select
          id="update-status"
          value={status}
          onChange={(e) => setStatus(e.target.value as ComplaintStatus)}
          className={`${inputClass} sm:w-auto`}
          disabled={busy}
        >
          <option>Pending</option>
          <option>Processing</option>
          <option>Resolved</option>
        </select>
        <button className={buttonClass} disabled={busy}>
          {busy ? "Saving…" : "Save status"}
        </button>
      </div>
      {message && <Feedback error={error}>{message}</Feedback>}
    </form>
  );
}
export default function ComplaintsTable({
  complaints = [],
  remoteFilters,
  onUpdateStatus,
}: ComplaintsTableProps) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<ComplaintStatus | "">("");
  const [selected, setSelected] = useState<string | null>(null);
  const rows = remoteFilters
    ? complaints
    : complaints.filter(
        (c) =>
          `${c.id} ${c.fullName} ${c.type}`
            .toLowerCase()
            .includes(query.toLowerCase()) &&
          (!status || c.status === status),
      );
  return (
    <div>
      <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_12rem]">
        <div>
          <label
            htmlFor="complaint-search"
            className="mb-1 block text-sm font-medium"
          >
            Search complaints
          </label>
          <input
            id="complaint-search"
            type="search"
            className={inputClass}
            value={remoteFilters?.search ?? query}
            onChange={(e) =>
              remoteFilters
                ? remoteFilters.onSearchChange(e.target.value)
                : setQuery(e.target.value)
            }
            placeholder="Name, ID, or complaint type"
          />
        </div>
        <div>
          <label
            htmlFor="status-filter"
            className="mb-1 block text-sm font-medium"
          >
            Status
          </label>
          <select
            id="status-filter"
            className={inputClass}
            value={remoteFilters?.status ?? status}
            onChange={(e) =>
              remoteFilters
                ? remoteFilters.onStatusChange(
                    e.target.value as ComplaintStatus | "",
                  )
                : setStatus(e.target.value as ComplaintStatus | "")
            }
          >
            <option value="">All statuses</option>
            <option>Pending</option>
            <option>Processing</option>
            <option>Resolved</option>
          </select>
        </div>
      </div>
      <p aria-live="polite" className="mb-3 text-sm text-slate-500">
        {rows.length} complaint{rows.length === 1 ? "" : "s"}
      </p>
      <div
        role="region"
        aria-label="Complaints table; scroll horizontally on smaller screens"
        tabIndex={0}
        className="overflow-x-auto rounded-lg border border-slate-200"
      >
        <table className="w-full min-w-[680px] border-collapse text-left text-sm">
          <caption className="sr-only">
            Complaints and their current status
          </caption>
          <thead className="bg-slate-50 text-teal-900">
            <tr>
              {[
                "ID",
                "Complainant",
                "Type",
                "Date filed",
                "Status",
                "Action",
              ].map((h) => (
                <th key={h} scope="col" className="px-4 py-4 font-semibold">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-500">
                  {remoteFilters?.search ||
                  remoteFilters?.status ||
                  complaints.length > 0
                    ? "No complaints match your search."
                    : "No complaints submitted yet."}
                </td>
              </tr>
            ) : (
              rows.map((row) => (
                <tr key={row.id} className="border-t border-slate-100">
                  <td className="max-w-40 break-words px-4 py-4 font-medium">
                    {row.id}
                  </td>
                  <td className="max-w-52 break-words px-4 py-4">
                    {row.fullName}
                  </td>
                  <td className="px-4 py-4">{row.type}</td>
                  <td className="whitespace-nowrap px-4 py-4">
                    <time dateTime={row.dateFiled}>{row.dateFiled}</time>
                  </td>
                  <td className="px-4 py-4">
                    <StatusBadge status={row.status} />
                  </td>
                  <td className="px-4 py-4">
                    <button
                      aria-expanded={selected === row.id}
                      aria-controls="complaint-details"
                      onClick={() =>
                        setSelected(selected === row.id ? null : row.id)
                      }
                      className="min-h-11 rounded px-2 font-semibold text-teal-700 underline"
                    >
                      {selected === row.id ? "Close" : "View"}
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <div id="complaint-details" aria-live="polite">
        {selected &&
          (() => {
            const row = rows.find((c) => c.id === selected);
            return row ? (
              <section
                aria-label={`Complaint ${row.id} details`}
                className="mt-4 break-words rounded-lg bg-teal-50 p-5"
              >
                <h3 className="font-semibold text-teal-900">
                  {row.id} · {row.type}
                </h3>
                <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">
                  {row.description || "No additional description available."}
                </p>
                {row.photoUrl && (
                  <a
                    href={row.photoUrl}
                    className="mt-3 inline-block min-h-11 py-3 text-sm font-semibold text-teal-800 underline"
                  >
                    Download evidence
                  </a>
                )}
                {onUpdateStatus && (
                  <StatusEditor
                    key={row.id + row.status}
                    row={row}
                    update={onUpdateStatus}
                  />
                )}
              </section>
            ) : null;
          })()}
      </div>
    </div>
  );
}
