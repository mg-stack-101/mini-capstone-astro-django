import type { ReactNode } from "react";
import type { ComplaintStatus } from "../lib/types";

export const inputClass =
  "w-full min-w-0 rounded-lg border border-slate-300 bg-white px-3 py-3 text-base text-slate-800 focus:border-teal-600";
export const buttonClass =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-teal-700 px-5 py-3 text-center text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:cursor-wait disabled:opacity-60";
export const cardClass =
  "min-w-0 rounded-2xl border border-slate-200/70 bg-white p-5 shadow-sm sm:p-7";

export function Brand({ light = false }: { light?: boolean }) {
  return (
    <a
      href="/"
      className={`flex min-w-0 items-center gap-3 ${light ? "text-white" : "text-teal-900"}`}
    >
      <span
        aria-hidden="true"
        className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-teal-500/15 text-2xl"
      >
        🏛️
      </span>
      <span className="text-sm font-bold leading-snug">
        BARANGAY COMPLAINT
        <span
          className={`block text-xs font-normal ${light ? "text-teal-200" : "text-slate-500"}`}
        >
          Monitoring System
        </span>
      </span>
    </a>
  );
}
export function Field({
  label,
  id,
  children,
}: {
  label: string;
  id: string;
  children: ReactNode;
}) {
  return (
    <div className="min-w-0">
      <label
        htmlFor={id}
        className="mb-2 block text-sm font-semibold text-slate-700"
      >
        {label}
      </label>
      {children}
    </div>
  );
}
export function Feedback({
  children,
  error = false,
}: {
  children: ReactNode;
  error?: boolean;
}) {
  return (
    <p
      role={error ? "alert" : "status"}
      className={`rounded-lg p-3 text-sm ${error ? "bg-red-50 text-red-800" : "bg-teal-50 text-teal-900"}`}
    >
      {children}
    </p>
  );
}
export function StatusBadge({ status }: { status: ComplaintStatus }) {
  const colors = {
    Pending: "bg-amber-100 text-amber-900",
    Processing: "bg-cyan-100 text-cyan-900",
    Resolved: "bg-emerald-100 text-emerald-900",
  };
  return (
    <span
      className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${colors[status]}`}
    >
      {status}
    </span>
  );
}
