"""Database configuration, kept separate from the main Django settings."""

import os

import dj_database_url
from django.core.exceptions import ImproperlyConfigured


def database_settings(base_dir):
    url = os.getenv("DATABASE_URL", "").strip()
    if not url:
        return {"ENGINE": "django.db.backends.sqlite3", "NAME": base_dir / "db.sqlite3"}

    database = dj_database_url.parse(url, conn_max_age=60, conn_health_checks=True)
    if database["ENGINE"] != "django.db.backends.postgresql":
        raise ImproperlyConfigured("DATABASE_URL must be a PostgreSQL connection URL.")

    database["DISABLE_SERVER_SIDE_CURSORS"] = True
    options = database.setdefault("OPTIONS", {})
    options.setdefault("sslmode", "require")
    options.setdefault("connect_timeout", 10)
    options["prepare_threshold"] = None
    return database
